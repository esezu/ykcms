<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv=refresh content="3;URL =/">
<title>您访问的页面不存在或已被删除</title>
<meta name="robots" content="nofollow">
<meta name="googlebot" content="nofollow">
<script type="text/javascript">window.setTimeout(function (){location.href="../../../index.htm"/*tpa=http://www.qyule0.com/*/;},3000)</script>
<style type="text/css">
body{font-size:14px}
.box{border:1px solid #999;width:500px;height:120px;margin:0 auto;padding:0}
.box h3{background-color:#eee;height:16px;line-height:16px;padding:3px;margin:0;font-size:14px}
.box p{padding:20px 10px 0 10px;margin:0;text-align:center}
.box a{color:blue}
</style>
</head>
<body>
<div class="box">
<h3>提示信息</h3>
<p>抱歉，该视频不存在或者该视频已经被管理员删除，点此观看该其他视频。</p> 
<p><a href="../../../index.htm"/*tpa=http://www.qyule0.com/*/>如果您的浏览器没有自动跳转，请点击这里</a></p>
</div>
</body>
</html>